import React, { Component, useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image, TouchableOpacity } from 'react-native';
import { scale, verticalScale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import HeaderComp from '../../Components/HeaderComp';
import ButtonComp from '../../Components/ButtonComp';
import styles from './styles';
import navigationStrings from '../../constants/navigationStrings'
import TextInputWithLabel from '../../Components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const SetPassword = ({ navigation }) => {
    const [isActive, setIsActive] = useState(false);
    const [isVisible, setVisible] = useState(true);
    return (
        <SafeAreaView style={{ flex: 1 }}>

            <View style={styles.container}>
                <HeaderComp />
                <Text style={styles.headingText}>Set Password</Text>
                <Text style={styles.descText}>Set Password for your new account <Text style={{fontWeight:'bold'}}>(+33) 34 56 78 901</Text></Text>

                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                    <TextInputWithLabel
                        label="Password"
                        placeholder="Enter your Password"
                        secureTextEntry={isVisible}
                        rightIcon={isVisible ? imagePath.hideEye : imagePath.showEye}
                        onPressRight={() => setVisible(!isVisible)}
                        inputStyle={{ marginVertical: moderateScale(76) }}
                    />
                   
                    <ButtonComp
                        btnStyle={styles.btnStyle}
                        btnText='Continue'
                        onPress={() => navigation.navigate(navigationStrings.SET_PASSWORD)}
                        img={imagePath.icForward}
                    />
                </KeyboardAwareScrollView>
            </View>
        </SafeAreaView >
    );
};

export default SetPassword;
