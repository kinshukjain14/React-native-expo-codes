let dummyData = [
    {
        id: 1,
        date: '25 JAN 2012',
        name:"Rowdy Rathore",
        address:"Ambala 24 sector",
        price: '$30'
    },
    {
        id: 2,
        date: '25 JAN 2012',
        name:"Rowdy Rathore",
        address:"Ambala 24 sector",
        price: '$30'
    },
    {
        id: 3,
        date: '25 JAN 2012',
        name:"Rowdy Rathore",
        address:"Ambala 24 sector",
        price: '$30'
    },
    {
        id: 435,
        date: '25 JAN 2012',
        name:"Rowdy Rathore",
        address:"Ambala 24 sector",
        price: '$30'
    },
    {
        id: 677667,
        date: '25 JAN 2012',
        name:"Rowdy Rathore",
        address:"Ambala 24 sector",
        price: '$30'
    },
]
// date: {
//     date: '25 JAN 2012'
// },
export default dummyData