import React, { useEffect,useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image, TouchableOpacity,Keyboard } from 'react-native';
import { scale, verticalScale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import HeaderComp from '../../Components/HeaderComp';
import ButtonComp from '../../Components/ButtonComp';
import styles from './styles';
import navigationStrings from '../../constants/navigationStrings'
import TextInputWithLabel from '../../Components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';

const ForgetPassword = ({ navigation }) => {
    // const[keyboardHeight,setKeyboardHeight] = useState(0)

    // useEffect(() =>{
    //     const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow',(event) =>{
    //         setKeyboardHeight(event.endCoordinates.height-50)
    //     })
    //     const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide',(event) =>{
    //         setKeyboardHeight(0)
    //     })
    //     return ()=>{
    //         keyboardDidShowListener.remove();
    //         keyboardDidHideListener.remove();
    //     }
    // },[])

    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
                <HeaderComp />
                <View style={{ flex: 1 }}>
                    <View style={{flex:0.2,alignItems: 'center',justifyContent: 'center'}}>
                        <Text>Lock Icon</Text>
                    </View>
                    <View style={{ flex: 0.4 }}>
                        <Text style={styles.headingText}>Forget Password</Text>
                        <Text style={styles.descText}>Enter the email address associated with your account</Text>
                    </View>
                    <View style={{ flex: 0.4 }}>
                    {/* <View style={{ flex: 0.4,marginBottom:keyboardHeight }}> */}
                        <TextInputWithLabel
                            label="Email Address"
                            inputStyle={{ marginBottom: moderateVerticalScale(28) }}
                            placeholder="Enter your email"
                            keyboardType='email-address'
                        />

                        <ButtonComp
                            btnText='Send'
                            onPress={() => navigation.navigate(navigationStrings.SET_PASSWORD)}
                        />
                    </View>
                </View>
            </View>
        </SafeAreaView >
    );
};

export default ForgetPassword;
