import React, { Component, useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image, TouchableOpacity } from 'react-native';
import { scale, verticalScale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import HeaderComp from '../../Components/HeaderComp';
import ButtonComp from '../../Components/ButtonComp';
import styles from './styles';
import navigationStrings from '../../constants/navigationStrings'
import TextInputWithLabel from '../../Components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const Register = ({ navigation }) => {
    const [isActive,setIsActive] = useState(false);
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
                <HeaderComp />
                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                <View style={{ flexDirection: 'row', }}>
                    <TextInputWithLabel
                        label="First Name"
                        inputStyle={{ flex: 1 }}
                        placeholder="Please enter your first name"
                    />
                    <View style={{ marginHorizontal: moderateScale(8) }}></View>
                    <TextInputWithLabel
                        label="Last Name"
                        inputStyle={{ flex: 1 }}
                        placeholder="Please enter your last name"
                    />
                </View>
                <TextInputWithLabel
                    label="Salo's name"
                    inputStyle={{ marginVertical: moderateVerticalScale(28) }}
                    placeholder="Please enter your salon name"
                />
                <TextInputWithLabel
                    label="Date of Birth"
                    // inputStyle={{marginVertical:moderateVerticalScale(28)}}
                    placeholder="Please enter your dob"
                />
                <TextInputWithLabel
                    label="Phone number"
                    inputStyle={{ marginVertical: moderateVerticalScale(28) }}
                    placeholder="Please enter your phone number"
                />
                <TextInputWithLabel
                    label="Email Address"
                    inputStyle={{ marginBottom: moderateVerticalScale(28) }}
                    placeholder="Enter your email"
                    keyboardType='email-address'
                />
                 <View style={{ flexDirection: 'row', }}>
                    <TextInputWithLabel
                        label="Country"
                        inputStyle={{ flex: 1 }}
                        placeholder="Enter Country"
                    />
                    <View style={{ marginHorizontal: moderateScale(8) }}></View>
                    <TextInputWithLabel
                        label="Postal/zip code"
                        inputStyle={{ flex: 1 }}
                        placeholder="Enter Postal/zip code"
                    />
                </View>
                <TextInputWithLabel
                    label="Address"
                    inputStyle={{ marginVertical: moderateVerticalScale(28) }}
                    placeholder="Please enter your address"
                />
                 <TextInputWithLabel
                    label="Referral code"
                    placeholder="Please enter your referral code"
                />
                <TouchableOpacity 
                style={styles.bottomView}
                activeOpacity={0.8}
                onPress={()=>setIsActive(!isActive)}
                >
                    <Image source={isActive ? imagePath.activeCheck : imagePath.inactiveCheck}
                        style={{marginRight:moderateScale(12)}}
                    />
                    <Text>By Logging in, you agree to NOOVV's Privacy Policy and Terms of Use</Text>
                </TouchableOpacity>
                <ButtonComp
                    btnStyle={{
                        marginVertical: moderateVerticalScale(32)

                    }}
                    btnText='Continue'
                    onPress={() => navigation.navigate(navigationStrings.SET_PASSWORD)}
                />
                </KeyboardAwareScrollView>
            </View>
        </SafeAreaView >
    );
};

export default Register;
