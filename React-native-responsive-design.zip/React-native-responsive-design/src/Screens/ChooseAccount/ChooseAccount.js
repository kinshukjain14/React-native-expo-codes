import React, { Component } from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import HeaderComp from '../../Components/HeaderComp';
import ButtonComp from '../../Components/ButtonComp';
import styles from './styles';
import navigationStrings from '../../constants/navigationStrings'

const ChooseAccount = ({ navigation}) => {
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={{ padding: moderateScale(24) }}>
                <HeaderComp />
            </View>
            <View style={styles.container}>
                <Text style={styles.headingText}>Choose your account type</Text>
                <View style={{ alignItems: 'center' }}>
                    <Image
                        source={{ uri: 'https://s3fs.paintnite.com/yaymaker-images/venue/original/wjgav-10014375-virtual-event-create-from-home.jpg' }}
                        style={styles.imgStyle}
                    />
                    <Text style={styles.textStyle}>Agency</Text>
                </View>
                <View style={{ alignItems: 'center' }}>
                    <Image
                        source={{ uri: 'https://cdn3.iconfinder.com/data/icons/business-avatar-1/512/11_avatar-512.png' }}
                        style={styles.imgStyle}
                    />
                    <Text style={styles.textStyle}>Freelancer</Text>
                </View>


                <ButtonComp
                    btnStyle={{
                        width: '100%',

                    }}
                    btnText='Continue'
                    onPress={() => navigation.navigate( navigationStrings.REGISTER )}
                />
            </View>
        </SafeAreaView>
    );
};

export default ChooseAccount;
