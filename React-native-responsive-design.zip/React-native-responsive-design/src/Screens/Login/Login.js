//import liraries
import React, { Component, useState } from 'react';
import { View, Text, Button, ImageBackground, TextInput, TouchableOpacity } from 'react-native';
import { moderateVerticalScale } from 'react-native-size-matters';
import ButtonComp from '../../Components/ButtonComp';
import TextInputWithLabel from '../../Components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';
import navigationStrings from '../../constants/navigationStrings'
import styles from './styles';

// create a component
const Login = ({ navigation }) => {
    const [isVisible, setVisible] = useState(true);
    return (
        <View style={styles.container}>
            <View>
                <ImageBackground
                    source={{ uri: 'https://cdn.mos.cms.futurecdn.net/3qpVahdh69fiUrJdswtfUn.jpg' }}
                    style={styles.imgStyle}
                >
                    <Text style={styles.loginTextStyle}>LOGIN</Text>
                </ImageBackground>
                <View style={styles.mainStyle}>
                    <TextInputWithLabel
                        label="Email Address"
                        inputStyle={{ marginBottom: moderateVerticalScale(28) }}
                        placeholder="Enter your email"
                        keyboardType='email-address'
                    />
                    <TextInputWithLabel
                        label="Password"
                        placeholder="Enter your Password"
                        secureTextEntry={isVisible}
                        rightIcon={isVisible ? imagePath.hideEye : imagePath.showEye}
                        onPressRight={() => setVisible(!isVisible)}
                    />
                    <TouchableOpacity activeOpacity={0.7} style={styles.forgetView} 
                    onPress={()=>navigation.navigate(navigationStrings.FORGET_PASSWORD)}>
                        <Text style={styles.forgetText}>Forget Password ?</Text>
                    </TouchableOpacity>
                    <ButtonComp
                        btnText="Login"
                    />
                </View>
            </View>
            <View style={styles.buttonView}>
                <Text>Not a member ? </Text>
                <TouchableOpacity onPress={() => navigation.navigate(navigationStrings.CHOOSE_ACCOUNT)}>
                    <Text>Join now</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default Login;           
