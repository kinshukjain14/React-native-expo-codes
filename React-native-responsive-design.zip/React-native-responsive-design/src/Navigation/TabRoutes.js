import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import navigationStrings from '../constants/navigationStrings';
import { Bookings, Home, Profile } from '../Screens';
import { Image } from 'react-native';
import imagePath from '../constants/imagePath';
import colors from '../styles/colors';

const BottomTab = createBottomTabNavigator();

export default function TabRoutes() {
    return (
        <BottomTab.Navigator screenOptions={{ 
            headerShown:false,
            tabBarInactiveTintColor:colors.blackOpacity50,
            tabBarActiveTintColor:colors.themeColor,
        }}>
            <BottomTab.Screen name={navigationStrings.HOME} component={Home}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (<Image style={{
                            tintColor: focused ? colors.themeColor : colors.blackOpacity50
                        }} source={imagePath.icHome} />)
                    }
                }} />
            <BottomTab.Screen name={navigationStrings.PROFILE} component={Profile}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (<Image style={{
                            tintColor: focused ? colors.themeColor : colors.blackOpacity50
                        }} source={imagePath.icProfile} />)
                    }
                }} />
            <BottomTab.Screen name={navigationStrings.BOOKINGS} component={Bookings}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (<Image style={{
                            tintColor: focused ? colors.themeColor : colors.blackOpacity50
                        }} source={imagePath.icBooking} />)
                    }
                }} />
        </BottomTab.Navigator>
    )
}