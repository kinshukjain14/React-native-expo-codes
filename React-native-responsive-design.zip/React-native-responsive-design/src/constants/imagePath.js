export default {
    showEye:require('../assets/images/show.png'),
    hideEye:require('../assets/images/hide.png'),
    icBack:require('../assets/images/back.png'), 
    activeCheck:require('../assets/images/activecheck.png'),
    inactiveCheck:require('../assets/images/inactivecheck.png'),
    icForward:require('../assets/images/forward.png'), 
    icHome:require('../assets/images/home.png'),
    icProfile:require('../assets/images/profile.png'),
    icBooking:require('../assets/images/booking.png'),
    icNotification:require('../assets/images/notification.png'),
    icLocation:require('../assets/images/location.png'),
}