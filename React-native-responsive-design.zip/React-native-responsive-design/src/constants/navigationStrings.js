export default {
    HOME:"Home",
    LOGIN:"Login",
    REGISTER:"Register",
    SET_PASSWORD:"SetPassword",
    FORGET_PASSWORD:"ForgotPassword",
    CHOOSE_ACCOUNT:"ChooseAccount",
    TAB_ROUTES:'tabRoutes',
    BOOKINGS:'Bookings',
    PROFILE:'Profile',
}