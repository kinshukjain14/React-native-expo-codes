import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Image, TouchableOpacity } from 'react-native';
import { scale, verticalScale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import colors from '../styles/colors';
import 'intl';

const TextInputWithLabel = ({
    label,
    placeholder,
    onChangeText = () => { },
    inputStyle,
    rightIcon,
    onPressRight,
    ...props
}) => {
    return (
        <View style={{ ...styles.inputStyle, ...inputStyle }}>
            <Text>{label}</Text>
            <View style={styles.flexView}>
                <TextInput
                    placeholder={placeholder}
                    style={styles.inputTextStyle}
                    // onChangeText={onChangeText}
                    {...props}
                />
                {!!rightIcon ? (
                <TouchableOpacity
                    activeOpacity={0.8}
                    onPress={onPressRight}
                >
                    <Image style={styles.iconStyle} source={rightIcon} />
                </TouchableOpacity>
                ) : null }
            </View>
        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    inputStyle: {
        borderBottomWidth: 1,
        borderBottomColor: colors.borderColor,
        borderRadius: moderateScale(4),
    },
    inputTextStyle: {
        padding: moderateVerticalScale(8),
        fontSize: scale(16),
        color: colors.blackOpacity80,
        flex:1,
    },
    labelTextStyle: {
        fontSize: scale(14),
        color: colors.blackOpacity50,
    },
    flexView: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    iconStyle: {
        tintColor: colors.blackOpacity30,
    }
});

export default TextInputWithLabel;
