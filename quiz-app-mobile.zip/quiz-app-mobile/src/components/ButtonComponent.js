//import liraries
import React, { Component } from 'react';
import {Button} from 'react-native-paper';

const ButtonComponent = ({
    labelText,
    mode='contained',
    btnStyle={},
    labelStyle={},
    onPress=() => { }
}) => {
    return (
       <Button
       mode={mode}
       style={btnStyle}
       labelStyle={labelStyle}
       onPress={onPress}>
           {labelText}
       </Button>
    );
};

export default ButtonComponent;
