//import liraries
import React, { Component,forwardRef, useState, useCallback } from 'react';
import DatePicker from 'react-native-datepicker';
import { View, Text, Platform } from 'react-native';
import { TextInput } from 'react-native-paper';
import TextInputComponent from './TextInputComponent';
const DatesPicker = forwardRef((props, ref) => {
    // const [date, setDate] = useState('2016-05-15')

    return (
        <>
            {/* <DatePicker
                date={date}
                mode="date"
                placeholder="select date"
                format="YYYY-MM-DD"
                minDate="2016-05-01"
                maxDate="2016-06-01"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                customStyles={{
                    dateIcon: {
                        position: 'absolute',
                        left: 0,
                        top: 4,
                        marginLeft: 0
                    },
                    dateInput: {
                        marginLeft: 36
                    }
                }}
                onDateChange={(date) => { setDate(date) }}
            /> */}
            <TextInputComponent
                inputStyle={props.inputStyle}
                mode={'outlined'}
                label={'Date of birth'}
                placeholder={'YYYY/MM/DD'}
                // value={!date ? '' : date.toUTCString()}
                rightSideIcon={<TextInput.Icon name={'calendar-range'} />
                }
            />
        </>
    );
});

export default DatesPicker;
