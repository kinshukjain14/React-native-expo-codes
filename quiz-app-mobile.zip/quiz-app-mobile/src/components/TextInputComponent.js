import React, {forwardRef } from 'react';
import { Text,View } from 'react-native';
import { TextInput } from 'react-native-paper';
import { moderateScale } from 'react-native-size-matters';
import colors from '../constants/colors';
const TextInputComponent = forwardRef(({
    inputStyle = {},
    label = '',
    mode = 'outlined',
    placeholder = '',
    rightSideIcon = null,
    leftSideIcon = null,
    secureEntry = false,
    ...otherProps
}, ref) => {
    return (
        <>
            <TextInput
                style={inputStyle}
                label={label}
                mode={mode}
                placeholder={placeholder}
                right={rightSideIcon}
                left={leftSideIcon}
                ref={ref}
                secureTextEntry={secureEntry}
                {...otherProps}
            />
            <View>
                <Text  style={{ color: colors.errorMsg, padding: moderateScale(1) }}>
                    {otherProps.touched ? otherProps.error : ''}
                </Text>
            </View>
        </>
    );
})

export default TextInputComponent;

