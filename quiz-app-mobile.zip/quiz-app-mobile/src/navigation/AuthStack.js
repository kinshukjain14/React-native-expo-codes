import {createNativeStackNavigator} from '@react-navigation/native-stack';
import navigationStrings from '../constants/navigationStrings';
import {
Welcome, Login, Register
} from '../screens'
const Stack = createNativeStackNavigator();

const AuthStack = () => {
    return (
        <Stack.Navigator  initialRouteName={navigationStrings.WELCOME} 
            screenOptions={{headerShown:false}}
        >
            <Stack.Screen name={navigationStrings.WELCOME} component={Welcome}  />
            <Stack.Screen name={navigationStrings.LOGIN} component={Login}  />
            <Stack.Screen name={navigationStrings.REGISTER} component={Register}  />
        </Stack.Navigator>
    );
};

export default AuthStack;
