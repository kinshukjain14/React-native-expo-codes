import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import AuthStack from './AuthStack';
import HomeStack from './HomeStack';

const Routes = () => {
    return (
        <NavigationContainer>
            {true ? AuthStack() : HomeStack()}
        </NavigationContainer>
    );
};
export default Routes;
