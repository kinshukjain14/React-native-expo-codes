import { StyleSheet } from 'react-native'
import colors from '../../constants/colors'
import { scale, moderateScale, moderateVerticalScale, verticalScale } from 'react-native-size-matters';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'space-between',
        backgroundColor: colors.backgroundColor,
    },
    logoStyle: {
        width:moderateScale(150),
        height:moderateScale(150),
        borderRadius: moderateScale(30),
    },
    logoTextStyle: {
        fontWeight: 'bold',
        fontSize: scale(22),
        color: colors.White,
        marginVertical: moderateVerticalScale(20),
    },
    linearGradientArea: {
        flex: 3,
        borderBottomLeftRadius:moderateScale(50),
        borderBottomRightRadius:moderateScale(50),
        alignItems:'center',
        justifyContent:'center',
    },
    bottomView: {
        flex: 1,
        justifyContent:'center',
        alignItems:'center',
    },
    btnStyle: {
        paddingHorizontal: moderateScale(30),
        paddingVertical: moderateScale(10),
        borderRadius: moderateScale(50),
        fontWeight: '800',
        backgroundColor: colors.welcomeButton, 
    },
    btnLabelStyle: {
        color: colors.White,
        fontWeight: 'bold',
        fontSize:scale(16),
    },
    
});

export default styles;