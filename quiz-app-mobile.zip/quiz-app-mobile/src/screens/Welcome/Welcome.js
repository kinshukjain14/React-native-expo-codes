import React from 'react';
import { View, Text, Image, SafeAreaView, StatusBar } from 'react-native';
import { Button } from 'react-native-paper';
import styles from './styles';
import {
    Logo
}
    from '../../assets';
import { LinearGradient } from 'expo-linear-gradient';
import { ButtonComponent } from '../../components';
import navigationStrings from '../../constants/navigationStrings';
const Welcome = ({ navigation }) => {
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
                <LinearGradient colors={['#644fe0', '#b24fe0', '#644fe0']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.linearGradientArea}>
                    {/* <StatusBar /> */}
                    <Image style={styles.logoStyle} source={Logo} />
                    <Text style={styles.logoTextStyle}>TechieQuizard</Text>
                </LinearGradient>
                <View style={styles.bottomView} >
                    <ButtonComponent
                        labelText={'Get Started'}
                        btnStyle={styles.btnStyle}
                        labelStyle={styles.btnLabelStyle}
                        onPress={() => { navigation.navigate(navigationStrings.LOGIN) }}
                    />
                </View>
            </View>
        </SafeAreaView>
    );
};

export default Welcome;
