import { StyleSheet } from 'react-native'
import colors from '../../constants/colors'
import { scale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.backgroundColor,
    },
    logoView:{
        flex:1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    logoTextStyle:{
        fontSize:scale(24),
        fontWeight:'bold',
        opacity:0.6,
        marginTop: moderateVerticalScale(20),
        textTransform:'uppercase',
    },
    formView:{
        flex:2,
        paddingHorizontal:moderateScale(35),
        paddingVertical:moderateVerticalScale(30),
    },
    inputTextStyle:{
        
    },
    btnStyle: {
        marginTop:moderateVerticalScale(20),
        padding: moderateScale(10),
        borderRadius: moderateScale(50),
        backgroundColor: colors.welcomeButton, 
    },
    btnLabelStyle: {
        fontSize: scale(14),
        fontWeight: 'bold',
    },
    newUserStyle:{
        alignSelf:'flex-end',
        fontSize:scale(12),
        fontWeight:'bold',
        marginTop: moderateVerticalScale(10),
    },
    radioBtnGroupStyle:{
        flexDirection: 'row',
    },
});

export default styles;