import React, { useCallback, useState } from 'react';
import { View, Text, SafeAreaView } from 'react-native';
import styles from './styles';
import { Avatar, RadioButton, TextInput } from 'react-native-paper'
import {
    UserLogo
} from '../../assets'
import { TextInputComponent, ButtonComponent, DatesPicker } from '../../components';
import navigationStrings from '../../constants/navigationStrings';
import { moderateScale } from 'react-native-size-matters';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import DropDown from 'react-native-paper-dropdown';

const Register = ({ navigation }) => {
    const [value, setValue] = useState('first');
    const [isVisible, setVisible] = useState(true);
    const [showDropDown, setShowDropDown] = useState(false);
    const [gender, setGender] = useState("");

    const genderList = [
        {
          label: "Male",
          value: "male",
        },
        {
          label: "Female",
          value: "female",
        },
        {
          label: "Others",
          value: "others",
        },
      ];

    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
                <View style={{ flex: 0.2 }} />
                <View style={styles.logoView}>
                    <Avatar.Image size={200}
                        source={{ uri: 'https://png.pngtree.com/element_our/png/20181112/meeting-icon-png_235912.jpg' }}
                    />
                    <Text style={styles.logoTextStyle}>SIGN UP</Text>
                </View>

                <View style={styles.formView}>
                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
                        <View style={{ flexDirection: 'row' }}>
                            <TextInputComponent
                                inputStyle={{ flex: 1 }}
                                mode={'outlined'}
                                label={'First Name'}
                                placeholder={'Enter First name'}
                            />
                            <View style={{ marginHorizontal: moderateScale(5) }} />
                            <TextInputComponent
                                inputStyle={{ flex: 1 }}
                                mode={'outlined'}
                                label={'Last Name'}
                                placeholder={'Enter Last name'}
                            />
                        </View>
                        <Text />
                        <TextInputComponent
                            mode={'outlined'}
                            label={'Contact'}
                            placeholder={'Enter contact number'}
                        />
                        <TextInputComponent
                            mode={'outlined'}
                            label={'Email'}
                            placeholder={'Enter email id'}
                        />
                        <Text style={{ fontWeight: 'bold' }}>Gender</Text>
                        <RadioButton.Group
                            onValueChange={newValue => setValue(newValue)} value={value}>
                            <View style={styles.radioBtnGroupStyle} >
                                <RadioButton.Item color={'blue'} value="M" label="Male" />
                                <RadioButton.Item color={'blue'} value="F" label="Female" />
                                <RadioButton.Item color={'blue'} value="O" label="Others" />
                            </View>
                        </RadioButton.Group>

                        <TextInputComponent
                            mode={'outlined'}
                            label={'Address'}
                            multiline={true}
                            numberOfLines={4}
                            placeholder={'Enter address'}
                        />
                        {
                        <DropDown
                            label={"Gender"}
                            mode={"outlined"}
                            visible={showDropDown}
                            showDropDown={() => setShowDropDown(true)}
                            onDismiss={() => setShowDropDown(false)}
                            value={gender}
                            setValue={setGender}
                            list={genderList}
                        />}
                        <Text/>
                        <TextInputComponent
                            mode={'outlined'}
                            label={'State'}
                            placeholder={'Select'}
                        />
                        <TextInputComponent
                            mode={'outlined'}
                            label={'City'}
                            placeholder={'Select'}
                        />
                        <TextInputComponent
                            mode={'outlined'}
                            inputStyle={styles.inputTextStyle}
                            placeholder={'Enter password'}
                            label={'Password'}
                            secureEntry={isVisible}
                            rightSideIcon={<TextInput.Icon name={!!isVisible ? 'eye-off' : 'eye'}
                                onPress={() => setVisible(!isVisible)} />
                            }
                        />
                        <TextInputComponent
                            mode={'outlined'}
                            inputStyle={styles.inputTextStyle}
                            placeholder={'Enter password'}
                            label={'Confirm Password'}
                            secureEntry={isVisible}
                            rightSideIcon={<TextInput.Icon name={!!isVisible ? 'eye-off' : 'eye'}
                                onPress={() => setVisible(!isVisible)} />
                            }
                        />
                        <ButtonComponent
                            labelText={'Sign Up'}
                            btnStyle={styles.btnStyle}
                            labelStyle={styles.btnLabelStyle}
                            onPress={() => handleSubmit()}
                        />
                    </KeyboardAwareScrollView>
                </View>
            </View>
        </SafeAreaView>
    );
};

export default Register;
