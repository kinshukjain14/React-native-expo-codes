export {default as Welcome} from './Welcome/Welcome';
export {default as Home} from './Home/Home';
export {default as Login} from './Login/Login';
export {default as Register} from './Register/Register';

