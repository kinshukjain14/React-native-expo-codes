import { StyleSheet } from 'react-native'
import colors from '../../constants/colors'
import { scale, moderateScale, moderateVerticalScale } from 'react-native-size-matters';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.backgroundColor,
    },
    logoView:{
        flex:1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imgStyle:{
        width: moderateScale(120),
        height: moderateScale(120),
        borderRadius:moderateScale(200),
    },
   
    logoTextStyle:{
        fontSize:scale(20),
        fontWeight:'bold',
        opacity:0.6,
        marginTop: moderateVerticalScale(10),
        textTransform:'uppercase',
    },
    formView:{
        flex:1,
        paddingHorizontal:moderateScale(35),
        paddingVertical:moderateVerticalScale(30),
    },
    
    inputTextStyle:{
        // marginTop: moderateVerticalScale(10),
        backgroundColor:colors.White,
    },
    btnStyle: {
        marginTop:moderateVerticalScale(20),
        padding: moderateScale(10),
        borderRadius: moderateScale(50),
        backgroundColor: colors.welcomeButton, 
    },
    btnLabelStyle: {
        fontSize: scale(14),
        fontWeight: 'bold',
    },
    newUserStyle:{
        alignSelf:'flex-end',
        fontWeight:'bold',
        flexWrap:'wrap',
        marginTop: moderateVerticalScale(2),
    }

});

export default styles;