//import liraries
import React, { useRef, useState } from 'react';
import { View, Text, SafeAreaView, TouchableOpacity } from 'react-native';
import styles from './styles';
import { Avatar, TextInput } from 'react-native-paper'
import {
    UserLogo
} from '../../assets'
import { TextInputComponent, ButtonComponent } from '../../components';
import navigationStrings from '../../constants/navigationStrings';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { scale } from 'react-native-size-matters';


const Login = ({ navigation }) => {

    const [isVisible, setVisible] = useState(true);
    const password = useRef(null);

    const LoginSchema = Yup.object().shape({
        email: Yup.string()
            .email('Invalid email')
            .required('Email is required'),
        password: Yup.string()
            .required("Password is required"),
    })

    const {
        handleChange,
        handleSubmit,
        handleBlur,
        values,
        errors,
        touched,
    } = useFormik({
        validationSchema: LoginSchema,
        initialValues: {
            email: '', password: ''
        },
        onSubmit: (values) => {
            alert(`Email : ${values.email}, Password: ${values.password}`);
        }
    });

    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.container}>
                <View style={{ flex: 0.2 }}/>
                <View style={styles.logoView}>
                    <Avatar.Image size={200}
                        source={{ uri: 'https://png.pngtree.com/element_our/png/20181112/meeting-icon-png_235912.jpg' }}
                    />
                    <Text style={styles.logoTextStyle}>SIGN IN</Text>
                </View>
                <View style={styles.formView}>
                    <TextInputComponent
                        mode={'outlined'}
                        inputStyle={styles.inputTextStyle}
                        placeholder={'Enter email id'}
                        label={'Email Id'}
                        keyboardType={'email-address'}
                        autoFocus={true}
                        returnKeyType={'next'}
                        blurOnSubmit={false}
                        onChangeText={handleChange('email')}
                        onBlur={handleBlur('email')}
                        error={errors.email}
                        touched={touched.email}
                        onSubmitEditing={() => password.current?.focus()}
                    />
                    <TextInputComponent
                        mode={'outlined'}
                        inputStyle={styles.inputTextStyle}
                        placeholder={'Enter password'}
                        label={'Password'}
                        secureEntry={isVisible}
                        rightSideIcon={<TextInput.Icon name={!!isVisible ? 'eye-off' : 'eye'}
                            onPress={() => setVisible(!isVisible)} />
                        }
                        ref={password}
                        blurOnSubmit={false}
                        onChangeText={handleChange('password')}
                        onBlur={handleBlur('password')}
                        error={errors.password}
                        touched={touched.password}
                        onSubmitEditing={() => handleSubmit()}
                    />

                    <TouchableOpacity style={styles.newUserStyle} onPress={() => navigation.navigate(navigationStrings.REGISTER)}>
                        <Text >New user? Join now</Text>
                    </TouchableOpacity>
                    <ButtonComponent
                        labelText={'Sign In'}
                        btnStyle={styles.btnStyle}
                        labelStyle={styles.btnLabelStyle}
                        onPress={() => handleSubmit()}
                    />
                </View>
            </View>
        </SafeAreaView>
    );
};

export default Login;
