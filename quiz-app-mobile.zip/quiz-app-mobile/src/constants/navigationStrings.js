export default {
    WELCOME : "Welcome",
    HOME: "Home",
    LOGIN: "Login",
    REGISTER: "Register", 
    TAB_ROUTE: "TabRoute"
}