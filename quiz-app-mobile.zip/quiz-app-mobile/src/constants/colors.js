export default { 
    White : 'white',
    backgroundColor :'#f2ebff',
    errorMsg :'red',
    welcomeButton:'#644fe0',
}