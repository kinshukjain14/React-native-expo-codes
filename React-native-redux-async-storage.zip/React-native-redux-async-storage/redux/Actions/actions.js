import axios from 'axios';
import { BASE_URL } from '../../config';

export const GET_BOOKS = 'GET_BOOKS';
export const ADD_TO_BOOKMARK_LIST = 'ADD_TO_BOOKMARK_LIST';
export const REMOVE_FROM_BOOKMARK_LIST = 'REMOVE_FROM_BOOKMARK_LIST';

export const getBooks = () => {
    try {
        return async (dispatch) => {
            const reponse = await axios.get(`${BASE_URL}`);
            if (reponse.data) {
                dispatch({
                    type: GET_BOOKS,
                    payload: reponse.data,
                })
            }
            else {
                console.log('Unable to fetch data from the API BASE URL!');
            }
        }
    }
    catch (e) {
        console.log(e);
    }

}

export const addBookmark = (book) => {
    return (dispatch) => {
        dispatch({
            type: ADD_TO_BOOKMARK_LIST,
            payload: book
        });
    };
}

export const removeBookmark = (book) => {
    return (dispatch) => {
        dispatch({
            type: REMOVE_FROM_BOOKMARK_LIST,
            payload: book
        });
    }
} 