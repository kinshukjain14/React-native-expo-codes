import {createStore,combineReducers,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import {bookReducer} from './Reducers';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { persistStore, persistReducer } from 'redux-persist';

const persistConfig = {
    key:'root',
    storage:AsyncStorage,
    whitelist:['bookmarks'],
}

const rootReducer = combineReducers({
    bookReducer:persistReducer(persistConfig,bookReducer)
});

export const store = createStore(rootReducer,applyMiddleware(thunk));
export const persistor = persistStore(store);
